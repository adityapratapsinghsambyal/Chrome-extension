chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "connectAll") {
      connectAll();
    }
  });
  
  function connectAll() {
    let connectButtons = document.querySelectorAll('button');
    connectButtons.forEach((btn) => {
      if (btn.innerText.includes('Connect')) {
        btn.click();
      }
    });
  }
  