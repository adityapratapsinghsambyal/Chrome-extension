document.getElementById('connectAll').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: connectAll
      });
    });
  });
  
  function connectAll() {
    // Find all visible 'Connect' buttons on the page and click them
    let connectButtons = document.querySelectorAll('button');
    connectButtons.forEach((btn) => {
      if (btn.innerText.includes('Connect')) {
        btn.click();
      }
    });
  }
  